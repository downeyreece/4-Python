Please use the following to cite the latest version of the Axelrod library::

    @misc{axelrodproject,
      author       = {{ {The Axelrod project developers} }}
      title        = {Axelrod: <RELEASE TITLE>},
      month        = apr,
      year         = 2016,
      doi          = {<DOI INFORMATION>},
      url          = {http://dx.doi.org/10.5281/zenodo.<DOI NUMBER>}
    }

To check the details (RELEASE TITLE, DOI INFORMATION and DOI NUMBER) please view
the Zenodo page for the project. Click on the badge/link below:

.. image:: https://zenodo.org/badge/19509/Axelrod-Python/Axelrod.svg
    :target: https://zenodo.org/badge/latestdoi/19509/Axelrod-Python/Axelrod
