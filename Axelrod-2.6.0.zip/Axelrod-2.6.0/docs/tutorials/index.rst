.. _tutorials:

Tutorials
=========

This section contains a variety of tutorials related to the Axelrod library.

Contents:

.. toctree::
   :maxdepth: 2

   getting_started/index.rst
   further_topics/index.rst
   advanced/index.rst
   contributing/index.rst
