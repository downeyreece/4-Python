Contributing to the library
===========================

All contributions (docs, tests, etc) are very welcome, if there is a specific
functionality that you would like to add then please open an issue (or indeed
take a look at the ones already there and jump in the conversation!).

If you want to work on documentation please keep in mind that doctests are
encouraged to help keep the documentation up to date.
