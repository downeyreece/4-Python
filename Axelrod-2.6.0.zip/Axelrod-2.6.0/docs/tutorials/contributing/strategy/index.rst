Contributing a strategy
=======================

This section contains a variety of tutorials that should help you contribute a
new strategy to the library.

Contents:

.. toctree::
   :maxdepth: 2

   instructions.rst
   writing_the_new_strategy.rst
   adding_the_new_strategy.rst
   classifying_the_new_strategy.rst
   writing_test_for_the_new_strategy.rst
   running_tests.rst
