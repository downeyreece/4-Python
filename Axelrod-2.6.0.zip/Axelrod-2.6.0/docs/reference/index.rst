Reference
=========

This section is the reference guide for the various components of the library.

Contents:

.. toctree::
   :maxdepth: 2

   description.rst
   play_contexts.rst
   overview_of_strategies.rst
   all_strategies.rst
   bibliography.rst
   glossary.rst
