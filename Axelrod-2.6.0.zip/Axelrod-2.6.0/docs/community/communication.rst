.. _communication:

Communication
-------------

There are various ways of communicating with the team:

- `Gitter: a web based chat client, you can talk directly to the users and
  maintainers of the library. <https://gitter.im/Axelrod-Python/Axelrod>`_
- Irc: we have an irc channel. It's #axelrod-python on freenode.
- `Email forum. <https://groups.google.com/forum/#!forum/axelrod-python>`_
- `Issues: you are also very welcome to open an issue on
  github <https://github.com/Axelrod-Python/Axelrod/issues>`_
- `Twitter. <https://twitter.com/AxelrodPython>`_ This account periodically
  tweets out random match and tournament results; you're welcome to get in
  touch through twitter as well.
