Citing the library
==================

We would be delighted if anyone wanted to use and/or reference this library for
their own research.

If you do please let us know and reference the library: as described in the
`CITATION.rst file on the library
repository
<https://github.com/Axelrod-Python/Axelrod/blob/master/CITATION.rst>`_.
